/*
 * Copyright (c) 2016-present Invertase Limited & Contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this library except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

// Export types from types/analytics
export type {
  Analytics,
  AnalyticsCallOptions,
  ConsentSettings,
  AnalyticsSettings,
  SettingsOptions,
  Currency,
  ConsentStatusString,
  Promotion,
  Item,
  AddPaymentInfoEventParameters,
  AddShippingInfoParameters,
  AddToCartEventParameters,
  AddToWishlistEventParameters,
  BeginCheckoutEventParameters,
  CampaignDetailsEventParameters,
  EarnVirtualCurrencyEventParameters,
  GenerateLeadEventParameters,
  JoinGroupEventParameters,
  LevelEndEventParameters,
  LevelStartEventParameters,
  LevelUpEventParameters,
  LoginEventParameters,
  PostScoreEventParameters,
  SelectContentEventParameters,
  PurchaseEventParameters,
  RefundEventParameters,
  RemoveFromCartEventParameters,
  SearchEventParameters,
  SelectItemEventParameters,
  SetCheckoutOptionEventParameters,
  SelectPromotionEventParameters,
  ShareEventParameters,
  SignUpEventParameters,
  SpendVirtualCurrencyEventParameters,
  UnlockAchievementEventParameters,
  ViewCartEventParameters,
  ViewItemEventParameters,
  ViewItemListEventParameters,
  ViewPromotionEventParameters,
  ViewSearchResultsParameters,
  ScreenViewParameters,
  EventParams,
  GtagConfigParams,
  EventNameString,
  CustomEventName,
  FirebaseAnalyticsTypes,
} from './types/analytics';

// Export modular API functions
export * from './modular';

// Export namespaced API
export * from './namespaced';
export { default } from './namespaced';
