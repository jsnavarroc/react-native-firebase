/*
 * Copyright (c) 2016-present Invertase Limited & Contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this library except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

import type { NativeErrorUserInfo, NativeError } from '../types/internal';

export default class NativeFirebaseError extends Error {
  readonly namespace!: string;
  readonly code!: string;
  readonly jsStack!: string;
  readonly userInfo!: NativeErrorUserInfo;
  readonly customData: any;
  readonly operationType!: string | null;
  readonly nativeErrorCode!: string | number | null;
  readonly nativeErrorMessage!: string | null;

  static fromEvent(
    errorEvent: NativeErrorUserInfo,
    namespace: string,
    stack?: string,
  ): NativeFirebaseError {
    return new NativeFirebaseError(
      { userInfo: errorEvent },
      stack ?? new Error().stack!,
      namespace,
    );
  }

  constructor(nativeError: NativeError, jsStack: string, namespace: string) {
    super();
    const { userInfo } = nativeError;

    Object.defineProperty(this, 'namespace', {
      enumerable: false,
      value: namespace,
    });

    Object.defineProperty(this, 'code', {
      enumerable: false,
      value: `${this.namespace}/${userInfo?.code ?? 'unknown'}`,
    });

    Object.defineProperty(this, 'message', {
      enumerable: false,
      value: `[${this.code}] ${userInfo?.message ?? nativeError.message}`,
    });

    Object.defineProperty(this, 'jsStack', {
      enumerable: false,
      value: jsStack,
    });

    Object.defineProperty(this, 'userInfo', {
      enumerable: false,
      value: userInfo,
    });

    // Needed for MFA processing of errors on web
    Object.defineProperty(this, 'customData', {
      enumerable: false,
      value: nativeError.customData ?? null,
    });

    // Needed for MFA processing of errors on web
    Object.defineProperty(this, 'operationType', {
      enumerable: false,
      value: nativeError.operationType ?? null,
    });

    Object.defineProperty(this, 'nativeErrorCode', {
      enumerable: false,
      value: userInfo?.nativeErrorCode ?? null,
    });

    Object.defineProperty(this, 'nativeErrorMessage', {
      enumerable: false,
      value: userInfo?.nativeErrorMessage ?? null,
    });

    this.stack = NativeFirebaseError.getStackWithMessage(
      `NativeFirebaseError: ${this.message}`,
      this.jsStack,
    );

    // Unused
    // this.nativeStackIOS = nativeError.nativeStackIOS;
    // this.nativeStackAndroid = nativeError.nativeStackAndroid;
  }

  /**
   * Build a stack trace that includes JS stack prior to calling the native method.
   *
   * @returns {string}
   */
  static getStackWithMessage(message: string, jsStack: string): string {
    return [message, ...jsStack.split('\n').slice(2, 13)].join('\n');
  }
}
